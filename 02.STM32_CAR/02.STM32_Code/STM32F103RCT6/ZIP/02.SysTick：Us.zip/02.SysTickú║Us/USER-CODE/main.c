#include "stm32f10x.h"
#include "BSP_SysTick.h"

int main()
{
	SysTick_Init();
	
	while(1){
	
	}
}
